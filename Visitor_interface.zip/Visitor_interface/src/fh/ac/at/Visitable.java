package fh.ac.at;

public interface Visitable {
    public double accept(Visitor visitor);
}
